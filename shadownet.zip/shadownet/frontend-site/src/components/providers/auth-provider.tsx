import { createContext, ReactNode, useContext, useState, useEffect } from "react";
import { UserRole } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

type User = {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  createdAt: Date;
};

// Тип данных для контекста аутентификации
type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: any;
  logoutMutation: any;
  registerMutation: any;
  isAdmin: boolean;
};

// Тип данных для входа
type LoginData = {
  username: string;
  password: string;
};

// Тип данных для регистрации
type RegisterData = {
  username: string;
  email: string;
  password: string;
};

// Создаем контекст с значением по умолчанию
const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: false,
  error: null,
  loginMutation: null,
  logoutMutation: null,
  registerMutation: null,
  isAdmin: false,
});

// Компонент провайдера
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Проверяем, авторизован ли пользователь при загрузке
  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await fetch("/api/user", {
          credentials: "include"
        });
        
        if (res.status === 401) {
          setUser(null);
          setIsLoading(false);
          return;
        }
        
        if (!res.ok) {
          throw new Error(`HTTP error: ${res.status}`);
        }
        
        const userData = await res.json();
        setUser(userData);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Unknown error'));
        console.error("Error fetching user:", err);
      } finally {
        setIsLoading(false);
      }
    }

    fetchUser();
  }, []);

  // Логика входа
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error(`Login failed: ${res.statusText}`);
      }
      
      return res.json();
    },
    onSuccess: (userData: User) => {
      setUser(userData);
      toast({
        title: "Успешный вход",
        description: "Добро пожаловать в ShadowNet",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка входа",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Логика регистрации
  const registerMutation = useMutation({
    mutationFn: async (credentials: RegisterData) => {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error(`Registration failed: ${res.statusText}`);
      }
      
      return res.json();
    },
    onSuccess: (userData: User) => {
      setUser(userData);
      toast({
        title: "Регистрация успешна",
        description: "Добро пожаловать в ShadowNet",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка регистрации",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Логика выхода
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/logout", {
        method: "POST",
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error(`Logout failed: ${res.statusText}`);
      }
    },
    onSuccess: () => {
      setUser(null);
      toast({
        title: "Выход выполнен",
        description: "Вы вышли из системы",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка выхода",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Проверка, является ли пользователь администратором
  const isAdmin = user?.role === UserRole.ADMIN;

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Хук для использования контекста
export function useAuth() {
  return useContext(AuthContext);
}