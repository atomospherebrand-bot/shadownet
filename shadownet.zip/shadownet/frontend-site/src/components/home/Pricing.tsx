import { useState } from "react";
import { Link } from "wouter";
import PlanCard from "@/components/common/PlanCard";
import { 
  CreditCard, 
  Bitcoin
} from "lucide-react";

type PricingProps = {
  showTitle?: boolean;
};

export default function Pricing({ showTitle = true }: PricingProps) {
  const plans = [
    {
      id: "monthly",
      title: "1 Месяц",
      price: 10,
      period: "мес",
      features: ["Все протоколы", "Безлимитный трафик", "5 устройств"],
      popular: false,
      savings: 0
    },
    {
      id: "yearly",
      title: "1 Год",
      price: 5,
      period: "мес",
      features: ["Все протоколы", "Безлимитный трафик", "10 устройств", "Приоритетная поддержка"],
      popular: true,
      savings: 50
    },
    {
      id: "biennial",
      title: "2 Года",
      price: 3,
      period: "мес",
      features: ["Все протоколы", "Безлимитный трафик", "Неограниченное количество устройств", "Приоритетная поддержка 24/7"],
      popular: false,
      savings: 70
    }
  ];

  const paymentMethods = [
    { icon: <CreditCard className="text-foreground w-5 h-5" />, name: "Карты" },
    { icon: <span className="text-foreground text-lg font-medium">M</span>, name: "MasterCard" },
    { icon: <span className="text-foreground font-medium">P</span>, name: "PayPal" },
    { icon: <Bitcoin className="text-foreground w-5 h-5" />, name: "Crypto" }
  ];

  return (
    <section id="pricing" className="py-16 bg-card relative circuit-bg">
      <div className="container">
        {showTitle && (
          <>
            <h2 className="font-bold text-3xl mb-2 text-center">Тарифы и Цены</h2>
            <p className="text-muted-foreground text-center mb-12">
              Выберите подходящий тарифный план для защиты вашей приватности
            </p>
          </>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {plans.map((plan) => (
            <PlanCard
              key={plan.id}
              title={plan.title}
              price={plan.price}
              period={plan.period}
              features={plan.features}
              popular={plan.popular}
              savings={plan.savings}
            />
          ))}
        </div>
        
        {/* Payment Methods */}
        <div className="mt-16">
          <h3 className="font-semibold text-xl mb-6 text-center">Способы Оплаты</h3>
          
          <div className="flex justify-center items-center space-x-8">
            {paymentMethods.map((method, index) => (
              <div 
                key={index} 
                className="w-12 h-12 bg-background/60 rounded-full flex items-center justify-center"
                title={method.name}
              >
                {method.icon}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
