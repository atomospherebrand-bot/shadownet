import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqItems = [
    {
      question: "Что такое VPN?",
      answer: "VPN (Virtual Private Network) — это технология, которая создает защищенное соединение между вашим устройством и интернетом, шифруя ваш трафик и скрывая ваш IP-адрес."
    },
    {
      question: "Чем отличаются протоколы Shadowsocks, VLESS и VMESS?",
      answer: "Эти протоколы отличаются методами шифрования, скоростью и способностью обходить блокировки. Shadowsocks оптимизирован для скорости, VLESS имеет минимальные накладные расходы, а VMESS обеспечивает дополнительную безопасность с динамическим шифрованием."
    },
    {
      question: "На скольких устройствах я могу использовать ShadowNet?",
      answer: "Количество устройств зависит от выбранного тарифа: 5 устройств для месячной подписки, 10 для годовой и неограниченное количество для двухлетней подписки."
    },
    {
      question: "Как я могу оплатить подписку?",
      answer: "Мы принимаем различные способы оплаты, включая кредитные карты (Visa, Mastercard), PayPal и криптовалюты для обеспечения анонимности."
    }
  ];

  return (
    <section id="faq" className="py-16 bg-background">
      <div className="container">
        <h2 className="font-bold text-3xl mb-12 text-center">Часто Задаваемые Вопросы</h2>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqItems.map((item, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card rounded-lg overflow-hidden border border-primary/20 px-0"
              >
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-primary/5 transition-colors duration-300">
                  <span className="text-left font-medium">{item.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-3 pt-0 text-muted-foreground">
                  <p>{item.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
