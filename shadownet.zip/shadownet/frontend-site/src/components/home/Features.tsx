import { ShieldCheck, Infinity, Lock } from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: <ShieldCheck className="h-6 w-6 text-primary" />,
      title: "Без Журналов Активности",
      description: "Мы не отслеживаем и не сохраняем информацию о вашей онлайн-активности."
    },
    {
      icon: <Infinity className="h-6 w-6 text-primary" />,
      title: "Безлимитный Трафик",
      description: "Наслаждайтесь безлимитной скоростью и объемом данных без ограничений."
    },
    {
      icon: <Lock className="h-6 w-6 text-primary" />,
      title: "Современное Шифрование",
      description: "Передовые технологии шифрования для максимальной защиты ваших данных."
    }
  ];

  return (
    <section id="features" className="py-16 bg-card">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-background/60 p-6 rounded-lg hover:shadow-[0_0_15px_rgba(255,215,0,0.15)] transition-all duration-300 border border-primary/20"
            >
              <div className="bg-background/60 w-16 h-16 rounded-full flex items-center justify-center mb-6 border border-primary/20">
                {feature.icon}
              </div>
              <h3 className="font-semibold text-xl mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
