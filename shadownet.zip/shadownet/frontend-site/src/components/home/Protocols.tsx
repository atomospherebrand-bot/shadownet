import ProtocolCard from "@/components/common/ProtocolCard";

export default function Protocols() {
  const protocols = [
    {
      name: "Shadowsocks",
      description: "Быстрый и безопасный протокол обхода блокировок с шифрованием трафика."
    },
    {
      name: "VLESS",
      description: "Легкий и эффективный протокол с минимальными накладными расходами."
    },
    {
      name: "VMESS",
      description: "Многофункциональный протокол с динамическим шифрованием и маскировкой."
    }
  ];

  return (
    <section id="protocols" className="py-16 bg-background">
      <div className="container">
        <h2 className="font-bold text-3xl mb-12 text-center">Поддерживаемые Протоколы</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {protocols.map((protocol, index) => (
            <ProtocolCard 
              key={index}
              name={protocol.name}
              description={protocol.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
