import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";

export default function Hero() {
  return (
    <section className="circuit-bg py-16 md:py-24 overflow-hidden relative">
      <div className="container flex flex-col md:flex-row items-center justify-between">
        <div className="md:w-1/2 mb-10 md:mb-0 z-10">
          <h1 className="font-bold text-3xl md:text-5xl mb-6 leading-tight">
            Защитите Вашу<br />
            <span className="text-primary">Приватность Онлайн</span>
          </h1>
          <p className="text-muted-foreground text-lg mb-8 max-w-lg">
            Безопасное и анонимное соединение с использованием протоколов Shadowsocks, VLESS и VMESS для максимальной защиты ваших данных.
          </p>
          <Link href="#pricing">
            <Button size="lg" className="font-medium text-black">
              Подключиться Сейчас
            </Button>
          </Link>
        </div>
        
        <div className="md:w-5/12 relative z-10">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/10 rounded-lg filter blur-xl"></div>
            <div className="relative z-10 w-full h-full rounded-lg overflow-hidden border border-primary/20">
              <svg 
                viewBox="0 0 400 300" 
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-auto"
              >
                <defs>
                  <linearGradient id="circuitGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#121212" />
                    <stop offset="100%" stopColor="#1E1E2D" />
                  </linearGradient>
                  <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#0088FF" />
                    <stop offset="100%" stopColor="#005599" />
                  </linearGradient>
                  <linearGradient id="glowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="rgba(0, 136, 255, 0.8)" />
                    <stop offset="100%" stopColor="rgba(0, 136, 255, 0.2)" />
                  </linearGradient>
                  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="10" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>
                
                <rect x="0" y="0" width="400" height="300" fill="url(#circuitGradient)" />
                
                {/* Circuit Background */}
                <path d="M10,50 L150,50 L170,70 L350,70" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M10,100 L50,100 L70,120 L350,120" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M50,50 L50,250" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M100,70 L100,250" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M150,120 L150,250" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M10,200 L150,200 L170,180 L350,180" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                <path d="M10,250 L50,250 L70,230 L350,230" stroke="#FFD700" strokeWidth="1" fill="none" opacity="0.3" />
                
                {/* Shield Glow */}
                <circle cx="200" cy="150" r="70" fill="url(#glowGradient)" filter="url(#glow)" />
                
                {/* Shield */}
                <path 
                  d="M200,100 L260,120 L260,180 C260,210 230,240 200,250 C170,240 140,210 140,180 L140,120 L200,100 Z" 
                  stroke="#0088FF" 
                  strokeWidth="4" 
                  fill="url(#shieldGradient)" 
                  fillOpacity="0.7"
                />
                
                {/* Lock in Shield */}
                <rect x="185" y="150" width="30" height="20" rx="2" fill="#FFD700" />
                <circle cx="200" cy="145" r="8" fill="#FFD700" />
                <rect x="195" y="137" width="10" height="16" rx="2" fill="#FFD700" />
              </svg>
            </div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-primary/10 backdrop-blur-sm flex items-center justify-center">
                <Shield className="w-12 h-12 md:w-16 md:h-16 text-primary" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Circuit decoration in the background */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-0"></div>
    </section>
  );
}
