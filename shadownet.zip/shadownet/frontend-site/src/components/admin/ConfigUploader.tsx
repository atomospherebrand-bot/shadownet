import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload, Trash2 } from "lucide-react";

export default function ConfigUploader() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("shadowsocks");
  const [configData, setConfigData] = useState({
    type: "shadowsocks",
    name: "",
    description: "",
    configText: "",
    serverAddress: "",
    port: "",
    qrCode: null as File | null
  });

  // Fetch existing configs
  const { data: configs, isLoading } = useQuery({
    queryKey: ["/api/admin/configs"],
  });

  // Add new config
  const addConfigMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest("POST", "/api/admin/configs", formData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/configs"] });
      toast({
        title: "Конфигурация добавлена",
        description: "Новая конфигурация успешно добавлена",
      });
      setConfigData({
        type: activeTab,
        name: "",
        description: "",
        configText: "",
        serverAddress: "",
        port: "",
        qrCode: null
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка добавления",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete config
  const deleteConfigMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/admin/configs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/configs"] });
      toast({
        title: "Конфигурация удалена",
        description: "Конфигурация успешно удалена",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка удаления",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setConfigData({
      ...configData,
      [e.target.name]: e.target.value
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setConfigData({
        ...configData,
        qrCode: e.target.files[0]
      });
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setConfigData({
      ...configData,
      type: value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!configData.name || !configData.serverAddress || !configData.port || !configData.configText) {
      toast({
        title: "Неверные данные",
        description: "Пожалуйста, заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("type", configData.type);
    formData.append("name", configData.name);
    formData.append("description", configData.description);
    formData.append("configText", configData.configText);
    formData.append("serverAddress", configData.serverAddress);
    formData.append("port", configData.port);
    if (configData.qrCode) {
      formData.append("qrCode", configData.qrCode);
    }

    addConfigMutation.mutate(formData);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Вы уверены, что хотите удалить эту конфигурацию?")) {
      deleteConfigMutation.mutate(id);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Добавить конфигурацию</CardTitle>
          <CardDescription>
            Загрузите QR-код и данные конфигурации для пользователей
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="mb-4">
                <TabsTrigger value="shadowsocks">Shadowsocks</TabsTrigger>
                <TabsTrigger value="vless">VLESS</TabsTrigger>
                <TabsTrigger value="vmess">VMESS</TabsTrigger>
              </TabsList>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Название конфигурации</Label>
                    <Input
                      id="name"
                      name="name"
                      value={configData.name}
                      onChange={handleInputChange}
                      placeholder="Введите название"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Описание</Label>
                    <Input
                      id="description"
                      name="description"
                      value={configData.description}
                      onChange={handleInputChange}
                      placeholder="Краткое описание"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="serverAddress">Адрес сервера</Label>
                    <Input
                      id="serverAddress"
                      name="serverAddress"
                      value={configData.serverAddress}
                      onChange={handleInputChange}
                      placeholder="example.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="port">Порт</Label>
                    <Input
                      id="port"
                      name="port"
                      value={configData.port}
                      onChange={handleInputChange}
                      placeholder="443"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="configText">Текст конфигурации</Label>
                  <Textarea
                    id="configText"
                    name="configText"
                    value={configData.configText}
                    onChange={handleInputChange}
                    placeholder="Введите текст конфигурации или URL"
                    rows={5}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="qrCode">QR-код (изображение)</Label>
                  <div className="mt-1">
                    <Input 
                      id="qrCode" 
                      type="file" 
                      onChange={handleFileChange} 
                      accept="image/*"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Загрузите изображение QR-кода для сканирования пользователями
                    </p>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  disabled={addConfigMutation.isPending}
                  className="mt-2"
                >
                  {addConfigMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Загрузка...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Добавить конфигурацию
                    </>
                  )}
                </Button>
              </div>
            </Tabs>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Существующие конфигурации</CardTitle>
          <CardDescription>
            Управление загруженными конфигурациями
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : configs && configs.length > 0 ? (
            <Tabs defaultValue="shadowsocks">
              <TabsList className="mb-4">
                <TabsTrigger value="shadowsocks">Shadowsocks</TabsTrigger>
                <TabsTrigger value="vless">VLESS</TabsTrigger>
                <TabsTrigger value="vmess">VMESS</TabsTrigger>
              </TabsList>
              
              {["shadowsocks", "vless", "vmess"].map((protocol) => (
                <TabsContent key={protocol} value={protocol}>
                  <div className="space-y-4">
                    {configs
                      .filter((config: any) => config.type === protocol)
                      .map((config: any) => (
                        <div 
                          key={config.id} 
                          className="flex items-center justify-between p-4 border border-border rounded-lg bg-card"
                        >
                          <div>
                            <h4 className="font-medium">{config.name}</h4>
                            <p className="text-sm text-muted-foreground">{config.serverAddress}:{config.port}</p>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleDelete(config.id)}
                              disabled={deleteConfigMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    
                    {configs.filter((config: any) => config.type === protocol).length === 0 && (
                      <p className="text-center py-4 text-muted-foreground">
                        Нет конфигураций для протокола {protocol}
                      </p>
                    )}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          ) : (
            <p className="text-center py-4 text-muted-foreground">
              Нет загруженных конфигураций
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
