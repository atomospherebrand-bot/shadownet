import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Loader2, Send } from 'lucide-react';

interface BotStatus {
  enabled: boolean;
  configured: boolean;
  hasToken: boolean;
  hasAdmins: boolean;
  botUsername?: string;
}

export function TelegramBotTest() {
  const [testMessage, setTestMessage] = useState('🧪 Тестовое сообщение от ShadowNet!\n\nБот работает корректно.');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);
  const [botStatus, setBotStatus] = useState<BotStatus | null>(null);

  const fetchBotStatus = async () => {
    try {
      const response = await fetch('/api/admin/bot-status');
      if (response.ok) {
        const status = await response.json();
        setBotStatus(status);
      }
    } catch (error) {
      console.error('Error fetching bot status:', error);
    }
  };

  const testBot = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/admin/test-telegram-bot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testMessage })
      });

      const data = await response.json();
      
      setResult({
        success: response.ok,
        message: data.message
      });
    } catch (error) {
      setResult({
        success: false,
        message: 'Ошибка соединения с сервером'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch bot status on component mount
  useState(() => {
    fetchBotStatus();
  });

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Send className="h-5 w-5" />
          <span>Тестирование Telegram бота</span>
        </CardTitle>
        <CardDescription>
          Проверьте работоспособность вашего Telegram бота
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Bot Status */}
        {botStatus && (
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${botStatus.enabled ? 'bg-green-500' : 'bg-gray-400'}`}></div>
              <span className="text-sm">Бот {botStatus.enabled ? 'включен' : 'отключен'}</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${botStatus.hasToken ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm">Токен {botStatus.hasToken ? 'настроен' : 'не настроен'}</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${botStatus.hasAdmins ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm">Админы {botStatus.hasAdmins ? 'настроены' : 'не настроены'}</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${botStatus.configured ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm">{botStatus.configured ? 'Готов к работе' : 'Требует настройки'}</span>
            </div>
          </div>
        )}

        {/* Test Message Input */}
        <div className="space-y-2">
          <Label htmlFor="test-message">Тестовое сообщение</Label>
          <textarea
            id="test-message"
            value={testMessage}
            onChange={(e) => setTestMessage(e.target.value)}
            className="w-full p-3 border rounded-lg bg-background min-h-[100px] resize-none"
            placeholder="Введите сообщение для тестирования..."
          />
          <p className="text-xs text-muted-foreground">
            Сообщение будет отправлено первому администратору из списка
          </p>
        </div>

        {/* Test Button */}
        <Button
          onClick={testBot}
          disabled={isLoading || !testMessage.trim()}
          className="w-full"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Отправка сообщения...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Отправить тестовое сообщение
            </>
          )}
        </Button>

        {/* Result */}
        {result && (
          <div className={`flex items-start space-x-3 p-4 rounded-lg border ${
            result.success 
              ? 'bg-green-50 border-green-200 text-green-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`}>
            {result.success ? (
              <CheckCircle className="h-5 w-5 mt-0.5 text-green-600" />
            ) : (
              <AlertCircle className="h-5 w-5 mt-0.5 text-red-600" />
            )}
            <div>
              <p className="font-medium">
                {result.success ? 'Успешно!' : 'Ошибка'}
              </p>
              <p className="text-sm">{result.message}</p>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">📋 Как настроить бота:</h4>
          <ol className="text-sm text-blue-800 space-y-1">
            <li>1. Откройте @BotFather в Telegram</li>
            <li>2. Создайте нового бота командой /newbot</li>
            <li>3. Скопируйте токен и вставьте в настройки выше</li>
            <li>4. Узнайте ваш Telegram ID у @userinfobot</li>
            <li>5. Добавьте ваш ID в поле "ID администраторов"</li>
            <li>6. Сохраните настройки и включите бота</li>
            <li>7. Протестируйте работу кнопкой выше</li>
          </ol>
        </div>

        {/* Bot Commands Preview */}
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-2">🤖 Команды бота:</h4>
          <div className="grid grid-cols-2 gap-2 text-sm text-gray-700">
            <div>/start - Приветствие</div>
            <div>/help - Справка</div>
            <div>/pricing - Тарифы</div>
            <div>/subscribe - Подписка</div>
            <div>/profile - Личный кабинет</div>
            <div>/support - Поддержка</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}