import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { getSubscriptionStatus, formatDate } from "@/lib/utils";
import { Loader2, RefreshCw, Plus, X } from "lucide-react";

export default function SubscriptionManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("active");
  const [searchQuery, setSearchQuery] = useState("");
  const [newSubscription, setNewSubscription] = useState({
    userId: "",
    username: "",
    planType: "monthly",
    durationMonths: 1,
  });

  // Fetch subscriptions
  const { data: subscriptions, isLoading } = useQuery({
    queryKey: ["/api/admin/subscriptions"],
  });

  // Fetch users for dropdown
  const { data: users } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  // Add subscription
  const addSubscriptionMutation = useMutation({
    mutationFn: async (data: typeof newSubscription) => {
      const res = await apiRequest("POST", "/api/admin/subscriptions", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/subscriptions"] });
      toast({
        title: "Подписка добавлена",
        description: "Подписка успешно добавлена пользователю",
      });
      setNewSubscription({
        userId: "",
        username: "",
        planType: "monthly",
        durationMonths: 1,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка добавления",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Cancel subscription
  const cancelSubscriptionMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/admin/subscriptions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/subscriptions"] });
      toast({
        title: "Подписка отменена",
        description: "Подписка успешно отменена",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка отмены",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewSubscription({
      ...newSubscription,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setNewSubscription({
      ...newSubscription,
      [name]: value
    });
  };

  const handleUserSelect = (userId: string) => {
    const selectedUser = users?.find((user: any) => user.id === userId);
    setNewSubscription({
      ...newSubscription,
      userId,
      username: selectedUser?.username || "",
    });
  };

  const handleAddSubscription = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newSubscription.userId) {
      toast({
        title: "Ошибка добавления",
        description: "Выберите пользователя",
        variant: "destructive",
      });
      return;
    }

    addSubscriptionMutation.mutate(newSubscription);
  };

  const handleCancelSubscription = (id: string) => {
    if (window.confirm("Вы уверены, что хотите отменить эту подписку?")) {
      cancelSubscriptionMutation.mutate(id);
    }
  };

  const filteredSubscriptions = subscriptions
    ? subscriptions.filter((sub: any) => {
        // Filter by status
        if (activeTab === "active" && sub.status !== "active") return false;
        if (activeTab === "expired" && sub.status !== "expired") return false;
        
        // Filter by search query
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          return (
            sub.user.username.toLowerCase().includes(query) ||
            sub.user.email.toLowerCase().includes(query)
          );
        }
        
        return true;
      })
    : [];

  const renderStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-600">Активна</Badge>;
      case "expiring":
        return <Badge className="bg-yellow-600">Скоро истекает</Badge>;
      case "expired":
        return <Badge className="bg-red-600">Истекла</Badge>;
      default:
        return <Badge className="bg-gray-600">Не активна</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Добавить подписку</CardTitle>
          <CardDescription>
            Добавьте новую подписку для пользователя
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddSubscription} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="userId">Пользователь</Label>
                <Select 
                  onValueChange={(value) => handleUserSelect(value)}
                  value={newSubscription.userId}
                >
                  <SelectTrigger id="userId">
                    <SelectValue placeholder="Выберите пользователя" />
                  </SelectTrigger>
                  <SelectContent>
                    {users?.map((user: any) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.username} ({user.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="planType">Тип плана</Label>
                <Select 
                  onValueChange={(value) => handleSelectChange("planType", value)}
                  value={newSubscription.planType}
                >
                  <SelectTrigger id="planType">
                    <SelectValue placeholder="Выберите план" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Ежемесячный</SelectItem>
                    <SelectItem value="yearly">Годовой</SelectItem>
                    <SelectItem value="biennial">Двухлетний</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="durationMonths">Длительность (месяцы)</Label>
                <Input
                  id="durationMonths"
                  name="durationMonths"
                  type="number"
                  min="1"
                  value={newSubscription.durationMonths}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <Button 
              type="submit" 
              disabled={addSubscriptionMutation.isPending}
            >
              {addSubscriptionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Добавление...
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Добавить подписку
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Управление подписками</CardTitle>
              <CardDescription>
                Просмотр и управление подписками пользователей
              </CardDescription>
            </div>
            <div className="mt-4 md:mt-0">
              <Input
                placeholder="Поиск по имени или email"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-xs"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="active">Активные</TabsTrigger>
              <TabsTrigger value="expired">Истекшие</TabsTrigger>
              <TabsTrigger value="all">Все</TabsTrigger>
            </TabsList>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredSubscriptions.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Пользователь</TableHead>
                      <TableHead>Тип</TableHead>
                      <TableHead>Статус</TableHead>
                      <TableHead>Начало</TableHead>
                      <TableHead>Окончание</TableHead>
                      <TableHead className="text-right">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSubscriptions.map((subscription: any) => (
                      <TableRow key={subscription.id}>
                        <TableCell className="font-medium">
                          <div>{subscription.user.username}</div>
                          <div className="text-xs text-muted-foreground">{subscription.user.email}</div>
                        </TableCell>
                        <TableCell>
                          {subscription.plan === "monthly" && "Ежемесячный"}
                          {subscription.plan === "yearly" && "Годовой"}
                          {subscription.plan === "biennial" && "Двухлетний"}
                        </TableCell>
                        <TableCell>
                          {renderStatusBadge(getSubscriptionStatus(subscription.endDate))}
                        </TableCell>
                        <TableCell>{formatDate(subscription.startDate)}</TableCell>
                        <TableCell>{formatDate(subscription.endDate)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => console.log('Extend subscription', subscription.id)}
                            >
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleCancelSubscription(subscription.id)}
                              disabled={cancelSubscriptionMutation.isPending}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                {searchQuery 
                  ? "Нет результатов по вашему запросу" 
                  : "Нет подписок в этой категории"}
              </div>
            )}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
