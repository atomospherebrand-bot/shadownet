import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save, Rocket } from "lucide-react";

export default function BotSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch bot settings
  const { data: botSettings, isLoading } = useQuery({
    queryKey: ["/api/admin/bot-settings"],
  });

  const [settings, setSettings] = useState({
    botToken: "",
    adminIds: "",
    welcomeMessage: "",
    enabled: false,
    notifyOnNewUser: false,
    notifyOnPurchase: false,
  });

  // Update settings when data is loaded
  useState(() => {
    if (botSettings) {
      setSettings({
        botToken: botSettings.botToken || "",
        adminIds: botSettings.adminIds ? botSettings.adminIds.join(",") : "",
        welcomeMessage: botSettings.welcomeMessage || "",
        enabled: botSettings.enabled || false,
        notifyOnNewUser: botSettings.notifyOnNewUser || false,
        notifyOnPurchase: botSettings.notifyOnPurchase || false,
      });
    }
  });

  // Save settings
  const saveMutation = useMutation({
    mutationFn: async (data: typeof settings) => {
      const res = await apiRequest("POST", "/api/admin/bot-settings", {
        ...data,
        adminIds: data.adminIds.split(",").map(id => id.trim()).filter(Boolean),
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bot-settings"] });
      toast({
        title: "Настройки сохранены",
        description: "Настройки Telegram бота успешно обновлены",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка сохранения",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Start/Stop bot
  const toggleBotMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      const res = await apiRequest("POST", `/api/admin/bot/${enabled ? 'start' : 'stop'}`);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bot-settings"] });
      toast({
        title: data.enabled ? "Бот запущен" : "Бот остановлен",
        description: data.enabled 
          ? "Telegram бот успешно запущен и готов к работе" 
          : "Telegram бот остановлен",
      });
      setSettings(prev => ({ ...prev, enabled: data.enabled }));
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка операции",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setSettings({
      ...settings,
      [e.target.name]: e.target.value
    });
  };

  const handleSwitchChange = (name: string, checked: boolean) => {
    setSettings({
      ...settings,
      [name]: checked
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(settings);
  };

  const toggleBot = () => {
    toggleBotMutation.mutate(!settings.enabled);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-10">
          <div className="flex justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Настройки Telegram бота</CardTitle>
            <CardDescription>
              Настройте параметры Telegram бота для автоматической продажи и поддержки
            </CardDescription>
          </div>
          <Button 
            onClick={toggleBot}
            variant={settings.enabled ? "destructive" : "default"}
            disabled={toggleBotMutation.isPending || !settings.botToken}
          >
            {toggleBotMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Rocket className="h-4 w-4 mr-2" />
            )}
            {settings.enabled ? "Остановить бота" : "Запустить бота"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="botToken">Токен бота</Label>
              <Input
                id="botToken"
                name="botToken"
                value={settings.botToken}
                onChange={handleInputChange}
                type="password"
                placeholder="123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ"
              />
              <p className="text-sm text-muted-foreground mt-1">
                Получите токен у @BotFather в Telegram
              </p>
            </div>
            
            <div>
              <Label htmlFor="adminIds">ID администраторов</Label>
              <Input
                id="adminIds"
                name="adminIds"
                value={settings.adminIds}
                onChange={handleInputChange}
                placeholder="123456789, 987654321"
              />
              <p className="text-sm text-muted-foreground mt-1">
                Укажите Telegram ID администраторов через запятую
              </p>
            </div>
            
            <div>
              <Label htmlFor="welcomeMessage">Приветственное сообщение</Label>
              <Textarea
                id="welcomeMessage"
                name="welcomeMessage"
                value={settings.welcomeMessage}
                onChange={handleInputChange}
                placeholder="Добро пожаловать в ShadowNet!"
                rows={4}
              />
            </div>
            
            <div className="flex items-center justify-between py-2">
              <div className="space-y-0.5">
                <Label htmlFor="notifyOnNewUser">Уведомлять о новых пользователях</Label>
                <p className="text-sm text-muted-foreground">
                  Отправлять уведомление при регистрации нового пользователя
                </p>
              </div>
              <Switch
                id="notifyOnNewUser"
                checked={settings.notifyOnNewUser}
                onCheckedChange={(checked) => handleSwitchChange("notifyOnNewUser", checked)}
              />
            </div>
            
            <div className="flex items-center justify-between py-2">
              <div className="space-y-0.5">
                <Label htmlFor="notifyOnPurchase">Уведомлять о покупках</Label>
                <p className="text-sm text-muted-foreground">
                  Отправлять уведомление при покупке подписки
                </p>
              </div>
              <Switch
                id="notifyOnPurchase"
                checked={settings.notifyOnPurchase}
                onCheckedChange={(checked) => handleSwitchChange("notifyOnPurchase", checked)}
              />
            </div>
          </div>
          
          <Button 
            type="submit" 
            disabled={saveMutation.isPending}
            className="w-full md:w-auto"
          >
            {saveMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Сохранение...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Сохранить настройки
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
