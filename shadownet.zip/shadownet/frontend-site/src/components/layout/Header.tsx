import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation, isAdmin } = useAuth();

  const isHomePage = location === "/";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navigation = [
    { name: "Особенности", href: isHomePage ? "#features" : "/#features" },
    { name: "Протоколы", href: isHomePage ? "#protocols" : "/#protocols" },
    { name: "Тарифы", href: isHomePage ? "#pricing" : "/#pricing" },
    { name: "FAQ", href: isHomePage ? "#faq" : "/#faq" },
  ];

  return (
    <header className="bg-background/80 backdrop-blur-md sticky top-0 z-50 border-b border-primary/20">
      <nav className="container mx-auto py-3 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <div className="w-10 h-10 relative">
            <svg className="w-10 h-10" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 5L5 12V28L20 35L35 28V12L20 5Z" stroke="hsl(var(--primary))" strokeWidth="2"/>
              <path d="M20 15L15 20M20 15L25 20M20 15V10M15 20V25M25 20V25M15 25L20 30M25 25L20 30" stroke="hsl(var(--primary))" strokeWidth="2"/>
            </svg>
          </div>
          <span className="text-primary font-bold text-xl tracking-wider">SHADOWNET</span>
        </Link>
        
        <div className="hidden md:flex items-center space-x-6">
          {navigation.map((item) => (
            <Link 
              key={item.name} 
              href={item.href} 
              className="text-foreground hover:text-primary transition-colors duration-300"
            >
              {item.name}
            </Link>
          ))}
          
          {user ? (
            <>
              <Link href="/dashboard">
                <Button variant="outline" className="mr-2">Личный кабинет</Button>
              </Link>
              {isAdmin && (
                <Link href="/admin">
                  <Button variant="outline" className="mr-2">Админ панель</Button>
                </Link>
              )}
              <Button onClick={handleLogout}>Выйти</Button>
            </>
          ) : (
            <>
              <Link href="/auth?tab=login">
                <Button variant="outline">Войти</Button>
              </Link>
              <Link href="/auth?tab=register">
                <Button>Регистрация</Button>
              </Link>
            </>
          )}
        </div>
        
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Открыть меню</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[350px]">
            <nav className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-6">
                <Link href="/" className="flex items-center space-x-2" onClick={() => setIsOpen(false)}>
                  <div className="w-8 h-8 relative">
                    <svg className="w-8 h-8" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M20 5L5 12V28L20 35L35 28V12L20 5Z" stroke="hsl(var(--primary))" strokeWidth="2"/>
                      <path d="M20 15L15 20M20 15L25 20M20 15V10M15 20V25M25 20V25M15 25L20 30M25 25L20 30" stroke="hsl(var(--primary))" strokeWidth="2"/>
                    </svg>
                  </div>
                  <span className="text-primary font-bold text-xl tracking-wider">SHADOWNET</span>
                </Link>
                <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                  <X className="h-6 w-6" />
                  <span className="sr-only">Закрыть меню</span>
                </Button>
              </div>
              
              <div className="space-y-4 mb-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="block py-2 text-foreground hover:text-primary transition-colors duration-300"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
              
              <div className="mt-auto space-y-4">
                {user ? (
                  <>
                    <Link href="/dashboard" onClick={() => setIsOpen(false)}>
                      <Button className="w-full" variant="outline">Личный кабинет</Button>
                    </Link>
                    {isAdmin && (
                      <Link href="/admin" onClick={() => setIsOpen(false)}>
                        <Button className="w-full" variant="outline">Админ панель</Button>
                      </Link>
                    )}
                    <Button className="w-full" onClick={() => { handleLogout(); setIsOpen(false); }}>
                      Выйти
                    </Button>
                  </>
                ) : (
                  <>
                    <Link href="/auth?tab=login" onClick={() => setIsOpen(false)}>
                      <Button className="w-full" variant="outline">Войти</Button>
                    </Link>
                    <Link href="/auth?tab=register" onClick={() => setIsOpen(false)}>
                      <Button className="w-full">Регистрация</Button>
                    </Link>
                  </>
                )}
              </div>
            </nav>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
