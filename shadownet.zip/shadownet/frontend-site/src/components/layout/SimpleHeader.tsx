import { Link } from "wouter";
import { useAuth } from "@/components/providers/auth-provider";
import { Button } from "@/components/ui/button";

export default function SimpleHeader() {
  const { user, logoutMutation } = useAuth();
  return (
    <header className="bg-background/80 backdrop-blur-md sticky top-0 z-50 border-b border-primary/20">
      <nav className="container mx-auto py-3 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <div className="w-10 h-10 relative">
            <svg className="w-10 h-10" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 5L5 12V28L20 35L35 28V12L20 5Z" stroke="hsl(var(--primary))" strokeWidth="2"/>
              <path d="M20 15L15 20M20 15L25 20M20 15V10M15 20V25M25 20V25M15 25L20 30M25 25L20 30" stroke="hsl(var(--primary))" strokeWidth="2"/>
            </svg>
          </div>
          <span className="text-primary font-bold text-xl tracking-wider">SHADOWNET</span>
        </Link>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <Button variant="outline" asChild>
                <Link href="/dashboard">Личный кабинет</Link>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => {
                  logoutMutation.mutate();
                }}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? "Выход..." : "Выйти"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" asChild>
                <Link href="/auth?tab=login">Войти</Link>
              </Button>
              <Button asChild>
                <Link href="/auth?tab=register">Регистрация</Link>
              </Button>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}