import { Link } from "wouter";
import { Mail, Send, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card py-12 border-t border-primary/20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h4 className="font-bold text-lg mb-4">О Нас</h4>
            <p className="text-muted-foreground mb-4">
              ShadowNet предоставляет надежные и безопасные VPN решения для защиты вашей приватности в интернете.
            </p>
          </div>
          
          {/* Support */}
          <div>
            <h4 className="font-bold text-lg mb-4">Поддержка</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Центр поддержки
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Руководства
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Статус серверов
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h4 className="font-bold text-lg mb-4">Правовая информация</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Условия использования
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Политика конфиденциальности
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors duration-300">
                  Политика возврата
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-4">Связаться с нами</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-center">
                <Mail className="h-4 w-4 mr-2 text-primary" />
                <a href="mailto:support@shadownet.ru" className="hover:text-primary transition-colors duration-300">
                  support@shadownet.ru
                </a>
              </li>
              <li className="flex items-center">
                <Send className="h-4 w-4 mr-2 text-primary" />
                <a href="#" className="hover:text-primary transition-colors duration-300">
                  @shadownet_support
                </a>
              </li>
            </ul>
            
            <div className="flex space-x-3 mt-4">
              <a 
                href="#" 
                className="w-8 h-8 rounded-full bg-background flex items-center justify-center hover:bg-primary/20 transition-colors duration-300"
              >
                <Send className="h-4 w-4 text-primary" />
              </a>
              <a 
                href="#" 
                className="w-8 h-8 rounded-full bg-background flex items-center justify-center hover:bg-primary/20 transition-colors duration-300"
              >
                <Github className="h-4 w-4 text-primary" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-primary/10 text-center text-muted-foreground text-sm">
          <p>© {new Date().getFullYear()} ShadowNet. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
}
