import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

type PlanCardProps = {
  title: string;
  price: number;
  period: string;
  features: string[];
  popular?: boolean;
  savings?: number;
};

export default function PlanCard({
  title,
  price,
  period,
  features,
  popular = false,
  savings = 0
}: PlanCardProps) {
  const { user } = useAuth();
  const [_, navigate] = useLocation();

  const handleSelectPlan = () => {
    if (!user) {
      navigate('/auth');
    } else {
      // TODO: Handle subscription process
      navigate('/dashboard');
    }
  };

  return (
    <div className={`price-card bg-background rounded-lg overflow-hidden border ${popular ? 'border-primary/50' : 'border-primary/20'} flex flex-col relative`}>
      {popular && (
        <div className="absolute top-0 right-0">
          <div className="bg-primary text-xs text-primary-foreground font-medium py-1 px-3 rounded-bl-lg">
            Популярный
          </div>
        </div>
      )}
      
      <div className="p-6 flex-grow">
        <h3 className="font-bold text-xl mb-2 text-center">{title}</h3>
        <div className="flex justify-center items-end mb-2">
          <span className="text-4xl font-bold text-primary">${price}</span>
          <span className="text-muted-foreground ml-1">/{period}</span>
        </div>
        
        {savings > 0 && (
          <p className="text-center text-primary text-sm mb-6">Экономия {savings}%</p>
        )}
        
        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="p-6 border-t border-primary/20">
        <Button
          onClick={handleSelectPlan}
          className={`w-full ${popular ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground'}`}
          variant={popular ? 'default' : 'outline'}
        >
          Выбрать
        </Button>
      </div>
    </div>
  );
}
