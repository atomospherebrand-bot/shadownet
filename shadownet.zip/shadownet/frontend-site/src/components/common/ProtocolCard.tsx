type ProtocolCardProps = {
  name: string;
  description: string;
};

export default function ProtocolCard({ name, description }: ProtocolCardProps) {
  return (
    <div className="protocol-card rounded-lg p-6 border border-primary/20">
      <h3 className="font-semibold text-xl mb-3 text-primary">{name}</h3>
      <p className="text-muted-foreground mb-4">
        {description}
      </p>
      <div className="h-1 w-16 bg-gradient-to-r from-primary to-primary/20 rounded-full"></div>
    </div>
  );
}
