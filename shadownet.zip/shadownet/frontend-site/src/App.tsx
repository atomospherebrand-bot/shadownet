import { Switch, Route } from "wouter";
import { ProtectedRoute } from "./lib/protected-route";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import AdminPage from "@/pages/admin-page";
import ConfigSelectionPage from "@/pages/config-selection-page";
import PaymentMethodsPage from "@/pages/payment-methods-page";
import TermsPage from "@/pages/terms-page";
import PrivacyPage from "@/pages/privacy-page";

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/terms" component={TermsPage} />
        <Route path="/privacy" component={PrivacyPage} />
        <ProtectedRoute path="/dashboard" component={DashboardPage} />
        <ProtectedRoute path="/admin" component={AdminPage} adminOnly={true} />
        <ProtectedRoute path="/config-selection" component={ConfigSelectionPage} />
        <Route path="/payment-methods" component={PaymentMethodsPage} />
        <Route path="/:rest*" component={NotFound} />
      </Switch>
    </div>
  );
}

export default App;
