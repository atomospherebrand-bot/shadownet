import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export enum UserRole {
  USER = "USER",
  ADMIN = "ADMIN"
}

export enum PlanType {
  MONTHLY = "monthly",
  YEARLY = "yearly",
  BIENNIAL = "biennial"
}

export enum SubscriptionStatus {
  ACTIVE = "active",
  EXPIRED = "expired",
  CANCELED = "canceled"
}

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").$type<UserRole>().default(UserRole.USER).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Config model (VPN configurations)
export const configs = pgTable("configs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // shadowsocks, vless, vmess
  name: text("name").notNull(),
  description: text("description"),
  configText: text("config_text").notNull(),
  serverAddress: text("server_address").notNull(),
  port: integer("port").notNull(),
  qrCodeUrl: text("qr_code_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertConfigSchema = createInsertSchema(configs).omit({
  id: true,
  createdAt: true,
});

export type InsertConfig = z.infer<typeof insertConfigSchema>;
export type Config = typeof configs.$inferSelect;

// Subscription model
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  planType: text("plan_type").$type<PlanType>().notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").$type<SubscriptionStatus>().default(SubscriptionStatus.ACTIVE).notNull(),
  devicesUsed: integer("devices_used").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Telegram Bot Settings
export const botSettings = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  botToken: text("bot_token").default("").notNull(),
  adminIds: json("admin_ids").$type<number[]>().default([]).notNull(),
  welcomeMessage: text("welcome_message").default("Добро пожаловать в ShadowNet! Используйте команды для управления VPN.").notNull(),
  enabled: boolean("enabled").default(false).notNull(),
  notifyOnNewUser: boolean("notify_on_new_user").default(false).notNull(),
  notifyOnPurchase: boolean("notify_on_purchase").default(false).notNull(),
});

export type BotSettings = typeof botSettings.$inferSelect;

// Payment transaction model (for keeping track of payments)
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  orderId: text("order_id").notNull(),
  amount: integer("amount").notNull(),
  planType: text("plan_type").$type<PlanType>().notNull(),
  status: text("status").notNull(), // success, failed, pending
  paymentMethod: text("payment_method").notNull(),
  transactionId: text("transaction_id"),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

// Payment Methods Configuration
export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'card', 'crypto'
  enabled: boolean("enabled").notNull().default(false),
  description: text("description"),
  fees: text("fees"), // e.g., "0.5%" or "Без комиссии"
  processingTime: text("processing_time"), // e.g., "Мгновенно", "10-60 минут"
  config: text("config"), // JSON config for payment processor
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type PaymentMethod = typeof paymentMethods.$inferSelect;

// FreeKassa Settings
export const freeKassaSettings = pgTable("freekassa_settings", {
  id: serial("id").primaryKey(),
  merchantId: text("merchant_id").notNull().default(''),
  secretKey1: text("secret_key_1").notNull().default(''),
  secretKey2: text("secret_key_2").notNull().default(''),
  enabled: boolean("enabled").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type FreeKassaSettings = typeof freeKassaSettings.$inferSelect;
